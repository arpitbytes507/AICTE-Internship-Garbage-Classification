import { P, a } from "./mermaid-parser.core.CYXMBtqd.js";
export {
  P as PacketModule,
  a as createPacketServices
};
