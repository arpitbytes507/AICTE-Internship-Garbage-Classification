import { A, e } from "./mermaid-parser.core.CYXMBtqd.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
